package dev.worldforge.troops.mc;

import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.logging.LogUtils;
import dev.worldforge.mod.api.TreasuryApi;
import dev.worldforge.troops.Formations;
import dev.worldforge.troops.Forts;
import dev.worldforge.troops.Muster;
import dev.worldforge.troops.Wars;
import dev.worldforge.troops.Squads;
import dev.worldforge.troops.TroopDefs;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.Commands;
import net.minecraft.commands.SharedSuggestionProvider;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.storage.LevelResource;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.EntityJoinLevelEvent;
import net.minecraftforge.event.entity.EntityLeaveLevelEvent;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.event.server.ServerStartedEvent;
import net.minecraftforge.event.server.ServerStoppingEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.ModList;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.simple.SimpleChannel;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;
import org.slf4j.Logger;

import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

/** wf-troops: физические солдаты и командный режим (клавиша R): выделить мышкой, приказать, держать строй. */
@Mod(TroopsMod.MOD_ID)
public class TroopsMod {
    public static final String MOD_ID = "wf_troops";
    public static final Logger LOGGER = LogUtils.getLogger();
    private static final String PROTO = "1";
    public static final SimpleChannel NET = NetworkRegistry.newSimpleChannel(new ResourceLocation(MOD_ID, "main"), () -> PROTO,
            NetworkRegistry.acceptMissingOr(PROTO), NetworkRegistry.acceptMissingOr(PROTO));

    private static final DeferredRegister<EntityType<?>> ENTITIES = DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, MOD_ID);
    public static final RegistryObject<EntityType<TroopEntity>> TROOP = ENTITIES.register("troop",
            () -> EntityType.Builder.<TroopEntity>of(TroopEntity::new, MobCategory.MISC).sized(0.6f, 1.95f).clientTrackingRange(12).build(MOD_ID + ":troop"));

    public static volatile TroopDefs DEFS = load(null);
    public static final Squads SQUADS = new Squads();
    public static final Forts FORTS = new Forts();
    public static final Map<String, TroopEntity> LIVE = new ConcurrentHashMap<>();
    private static MinecraftServer server;
    private static int ticks;

    public TroopsMod() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        ENTITIES.register(bus);
        bus.addListener((EntityAttributeCreationEvent e) -> e.put(TROOP.get(), TroopEntity.attributes().build()));
        bus.addListener((net.minecraftforge.fml.event.lifecycle.FMLCommonSetupEvent e) ->
                NET.registerMessage(0, OrderPacket.class, OrderPacket::encode, OrderPacket::decode, OrderPacket::handle));
        MinecraftForge.EVENT_BUS.register(this);
    }

    static TroopDefs load(Path override) {
        TroopDefs d = new TroopDefs();
        try (InputStream in = TroopsMod.class.getResourceAsStream("/data/wf_troops/wf_troops/units.json")) {
            if (in != null) d.load(new String(in.readAllBytes(), StandardCharsets.UTF_8));
            if (override != null && Files.exists(override)) d.load(Files.readString(override));      // файл мира дополняет и заменяет типы
        } catch (Exception e) {
            LOGGER.error("units.json: {}", e.toString());
        }
        for (String err : d.validate()) LOGGER.warn("wf-troops: {}", err);
        return d;
    }

    private static Path dir(MinecraftServer s) { return s.getWorldPath(LevelResource.ROOT).resolve("worldforge"); }

    @SubscribeEvent
    public void started(ServerStartedEvent e) {
        server = e.getServer();
        DEFS = load(dir(server).resolve("wf_troops_units.json"));
        try {
            Path f = dir(server).resolve("wf_squads.json");
            if (Files.exists(f)) SQUADS.fromJson(Files.readString(f));
            Path ff = dir(server).resolve("wf_forts.json");
            if (Files.exists(ff)) FORTS.fromJson(Files.readString(ff));
        } catch (Exception ex) {
            LOGGER.error("wf_squads.json: {}", ex.toString());
        }
    }

    @SubscribeEvent
    public void stopping(ServerStoppingEvent e) { save(); LIVE.clear(); server = null; }

    static void save() {
        if (server == null) return;
        try {
            Files.createDirectories(dir(server));
            Files.writeString(dir(server).resolve("wf_squads.json"), SQUADS.toJson());
            Files.writeString(dir(server).resolve("wf_forts.json"), FORTS.toJson());
        } catch (Exception ex) {
            LOGGER.error("save squads: {}", ex.toString());
        }
    }

    @SubscribeEvent
    public void join(EntityJoinLevelEvent e) {
        if (e.getLevel().isClientSide || !(e.getEntity() instanceof TroopEntity t)) return;
        LIVE.put(t.getUUID().toString(), t);
        if (SQUADS.squadOf(t.getUUID().toString()) == null) {                       // солдат без отряда (отряд потерян): свой отряд
            Squads.Squad s = SQUADS.create(t.ownerId(), null, List.of(t.getUUID().toString()));
            s.realm = t.realm; s.cx = t.getX(); s.cz = t.getZ();
            t.setSquadId(s.id);
        } else t.setSquadId(SQUADS.squadOf(t.getUUID().toString()).id);
    }

    @SubscribeEvent
    public void leave(EntityLeaveLevelEvent e) {
        if (e.getLevel().isClientSide || !(e.getEntity() instanceof TroopEntity t)) return;
        LIVE.remove(t.getUUID().toString());
    }

    static void onDeath(TroopEntity t) {
        String id = t.getUUID().toString();
        LIVE.remove(id);
        SQUADS.remove(id);
    }

    @SubscribeEvent
    public void tick(TickEvent.ServerTickEvent e) {
        if (e.phase != TickEvent.Phase.END || server == null) return;
        ticks++;
        if (ticks % 10 == 0) TroopController.step(server);
        if (ticks % 100 == 0) payroll();
        if (ticks % 20 == 0) FortService.step(server, ticks);
        if (ticks % 6000 == 0) save();
    }

    // ---- жалованье ----
    private static final Random RNG = new Random();

    /** Раз в игровой день: государства платят солдатам из казны; не заплатили - четверть разбегается. */
    private static void payroll() {
        int days = dev.worldforge.mod.api.WorldForgeApi.clock().pull("wf_troops");
        if (days <= 0) return;
        Map<String, List<TroopEntity>> byRealm = new LinkedHashMap<>();
        for (TroopEntity t : LIVE.values()) if (t.isAlive() && !t.realm.isEmpty()) byRealm.computeIfAbsent(t.realm, k -> new ArrayList<>()).add(t);
        for (var e : byRealm.entrySet()) {
            Map<String, Integer> counts = new HashMap<>();
            for (TroopEntity t : e.getValue()) counts.merge(t.unitId(), 1, Integer::sum);
            double cost = Muster.upkeep(DEFS, counts) * days;
            if (cost <= 0 || TreasuryApi.spend(e.getKey(), cost, "Жалованье солдат")) continue;
            List<TroopEntity> list = e.getValue();
            for (int i : Muster.deserters(list.size(), RNG)) {
                TroopEntity t = list.get(i);
                onDeath(t);
                t.discard();
            }
        }
    }

    // ---- приказы от клиента ----
    static void handleOrder(ServerPlayer p, OrderPacket o) {
        String owner = p.getUUID().toString();
        switch (o.action()) {
            case OrderPacket.ORDER -> {
                Squads.Order ord = o.kind() == Squads.Kind.ATTACK.ordinal() ? new Squads.Order(Squads.Kind.ATTACK, 0, 0, o.target())
                        : new Squads.Order(Squads.Kind.values()[Math.max(0, Math.min(o.kind(), Squads.Kind.values().length - 1))], o.x(), o.z(), o.target());
                for (String id : troopIds(o)) {
                    Squads.Squad rs = SQUADS.squadOf(id);
                    if (rs != null && rs.owner.equals(owner) && rs.routed && ord.kind() != Squads.Kind.STOP) {
                        p.displayClientMessage(Component.literal("Отряд «" + rs.name + "» бежит и не слушает приказов"), true);
                        return;
                    }
                }
                Squads.Squad s = SQUADS.commandUnits(owner, troopIds(o), ord, o.queue());
                if (s != null) p.displayClientMessage(Component.literal(s.name + " (" + s.members.size() + "): " + ord.kind().title), true);
            }
            case OrderPacket.FORMATION, OrderPacket.STANCE -> {
                Set<Squads.Squad> hit = new LinkedHashSet<>();
                for (String id : troopIds(o)) { Squads.Squad s = SQUADS.squadOf(id); if (s != null && s.owner.equals(owner)) hit.add(s); }
                for (Squads.Squad s : hit) {
                    if (o.action() == OrderPacket.FORMATION) s.formation = Formations.Type.values()[Math.floorMod(o.arg(), Formations.Type.values().length)];
                    else s.stance = Squads.Stance.values()[Math.floorMod(o.arg(), Squads.Stance.values().length)];
                }
                if (!hit.isEmpty()) {
                    Squads.Squad f = hit.iterator().next();
                    p.displayClientMessage(Component.literal(o.action() == OrderPacket.FORMATION ? "Строй: " + f.formation.title : "Поза: " + f.stance.title), true);
                }
            }
            case OrderPacket.GROUP -> {
                List<String> ids = new ArrayList<>();
                for (String id : troopIds(o)) { Squads.Squad s = SQUADS.squadOf(id); if (s != null && s.owner.equals(owner)) ids.add(id); }
                if (!ids.isEmpty()) {
                    Squads.Squad n = SQUADS.create(owner, null, ids);
                    for (String id : ids) { TroopEntity t = LIVE.get(id); if (t != null) t.setSquadId(n.id); }
                    p.displayClientMessage(Component.literal("Собран " + n.name + " (" + n.members.size() + ")"), true);
                }
            }
            case OrderPacket.WORK, OrderPacket.RELEASE -> {
                if (!ModList.get().isLoaded("wf_settle") || !WorkerControl.anyWorker(p, o)) return;
                if (!may(p)) { p.displayClientMessage(Component.literal("Рабочими управляют операторы"), true); return; }
                p.displayClientMessage(Component.literal(WorkerControl.command(p, o)), true);
            }
            case OrderPacket.BUILD_LIST -> {
                if (!ModList.get().isLoaded("wf_settle")) { p.displayClientMessage(Component.literal("Нужен мод wf_settle"), true); return; }
                BuildControl.sendList(p, o.x(), o.z());
            }
            case OrderPacket.BUILD -> {
                if (!ModList.get().isLoaded("wf_settle")) return;
                if (!may(p)) { p.displayClientMessage(Component.literal("Строить могут операторы"), true); return; }
                p.displayClientMessage(Component.literal(BuildControl.place(p, o.target(), (int) Math.floor(o.x()), (int) Math.floor(o.z()), o.ids())), true);
            }
            default -> {}
        }
    }

    private static final Map<String, Boolean> WAR_CACHE = new ConcurrentHashMap<>();
    private static int warCacheTick = -1000;

    private static Object enemiesOf(String realm) {
        for (dev.worldforge.mod.MapData m : dev.worldforge.mod.WorldForgeMod.loadedMaps().values()) {
            if (m.titles == null) continue;
            dev.worldforge.mod.TitleData.Realm r = m.titles.realms.get(realm);
            if (r != null) return r.props.get("enemies");
        }
        return null;
    }

    /** Воюют ли государства солдат (кэш на 5 секунд: вызывается на каждый поиск цели). */
    static boolean atWar(String a, String b) {
        if (a == null || b == null || a.isEmpty() || b.isEmpty() || a.equals(b)) return false;
        if (ticks - warCacheTick > 100) { WAR_CACHE.clear(); warCacheTick = ticks; }
        return WAR_CACHE.computeIfAbsent(a.compareTo(b) < 0 ? a + "|" + b : b + "|" + a, k -> Wars.atWar(a, enemiesOf(a), b, enemiesOf(b)));
    }

    /** Защитники крепости и чужие солдаты, для которых она вражеская, враждуют сами, без приказов. */
    static boolean fortHostile(TroopEntity a, TroopEntity b) {
        if (a.fortId > 0 && b.fortId != a.fortId) { Forts.Fort f = FORTS.get(a.fortId); if (f != null && f.hostileTo(b.ownerId(), b.realm)) return true; }
        if (b.fortId > 0 && a.fortId != b.fortId) { Forts.Fort f = FORTS.get(b.fortId); if (f != null && f.hostileTo(a.ownerId(), a.realm)) return true; }
        return false;
    }

    /** Операторы и владелец одиночного мира: стройкой и рабочими управляют они (как командами /wfsettle). */
    static boolean may(ServerPlayer p) { return p.hasPermissions(2) || p.server.isSingleplayerOwner(p.getGameProfile()); }

    private static List<String> troopIds(OrderPacket o) {
        List<String> r = new ArrayList<>();
        for (String id : o.ids()) if (LIVE.containsKey(id)) r.add(id);
        return r;
    }

    // ---- команды ----
    @SubscribeEvent
    public void commands(RegisterCommandsEvent e) {
        e.getDispatcher().register(Commands.literal("wftroops")
                .then(Commands.literal("types").executes(c -> {
                    for (TroopDefs.Unit u : DEFS.units.values())
                        c.getSource().sendSuccess(() -> Component.literal(u.id() + ": " + u.name() + " [" + u.role() + "] " + u.cost() + " зол."), false);
                    return 1;
                }))
                .then(Commands.literal("raise")
                        .then(Commands.argument("type", StringArgumentType.word()).suggests((c, b) -> SharedSuggestionProvider.suggest(DEFS.units.keySet(), b))
                                .then(Commands.argument("n", IntegerArgumentType.integer(1, Squads.MAX_SIZE)).executes(c -> raise(c.getSource(), StringArgumentType.getString(c, "type"), IntegerArgumentType.getInteger(c, "n"), ""))
                                        .then(Commands.argument("realm", StringArgumentType.word()).requires(s -> s.hasPermission(2))
                                                .executes(c -> raise(c.getSource(), StringArgumentType.getString(c, "type"), IntegerArgumentType.getInteger(c, "n"), StringArgumentType.getString(c, "realm")))))))
                .then(FortService.commands())
                .then(Commands.literal("muster").requires(s -> s.hasPermission(2))
                        .then(Commands.argument("army", IntegerArgumentType.integer(1))
                                .then(Commands.argument("n", IntegerArgumentType.integer(1, Squads.MAX_SIZE)).executes(c -> muster(c.getSource(), IntegerArgumentType.getInteger(c, "army"), IntegerArgumentType.getInteger(c, "n"))))))
                .then(Commands.literal("return").requires(s -> s.hasPermission(2)).executes(c -> returnToArmy(c.getSource())))
                .then(Commands.literal("list").executes(c -> {
                    try {
                        String json = SQUADS.viewJson(c.getSource().getPlayerOrException().getUUID().toString());
                        c.getSource().sendSuccess(() -> Component.literal(json), false);
                    } catch (Exception ex) {
                        c.getSource().sendFailure(Component.literal("Только для игрока"));
                    }
                    return 1;
                }))
                .then(Commands.literal("disband").executes(c -> {
                    try {
                        ServerPlayer p = c.getSource().getPlayerOrException();
                        int n = 0;
                        for (Squads.Squad s : new ArrayList<>(SQUADS.of(p.getUUID().toString()))) {
                            for (String id : new ArrayList<>(s.members)) { TroopEntity t = LIVE.get(id); if (t != null) { t.discard(); n++; } SQUADS.remove(id); }
                        }
                        int cnt = n;
                        c.getSource().sendSuccess(() -> Component.literal("Распущено солдат: " + cnt), false);
                    } catch (Exception ex) {
                        c.getSource().sendFailure(Component.literal("Только для игрока"));
                    }
                    return 1;
                })));
    }

    /** Наём отряда: платит игрок золотыми самородками (оператор в творческом режиме - бесплатно) или казна государства (realm, только оператор). */
    private static int raise(CommandSourceStack src, String type, int n, String realm) {
        ServerPlayer p;
        try {
            p = src.getPlayerOrException();
        } catch (Exception ex) {
            src.sendFailure(Component.literal("Только для игрока"));
            return 0;
        }
        TroopDefs.Unit u = DEFS.units.get(type);
        if (u == null) { src.sendFailure(Component.literal("Нет такого типа: " + type)); return 0; }
        int cost = u.cost() * n;
        if (!realm.isEmpty()) {
            if (!TreasuryApi.spend(realm, cost, "Наём: " + u.name())) { src.sendFailure(Component.literal("В казне " + realm + " не хватает золота: нужно " + cost)); return 0; }
        } else if (!p.isCreative()) {
            int have = 0;
            for (var st : p.getInventory().items) if (st.is(Items.GOLD_NUGGET)) have += st.getCount();
            if (have < cost) { src.sendFailure(Component.literal("Нужно " + cost + " золотых самородков, есть " + have)); return 0; }
            int left = cost;
            for (var st : p.getInventory().items) if (left > 0 && st.is(Items.GOLD_NUGGET)) { int take = Math.min(left, st.getCount()); st.shrink(take); left -= take; }
        }
        ServerLevel lv = p.serverLevel();
        List<String> ids = new ArrayList<>();
        List<TroopEntity> made = new ArrayList<>();
        List<Formations.Slot> slots = Formations.slots(Formations.Type.BLOCK, n, 1.6);
        List<double[]> pos = Formations.place(slots, p.getX(), p.getZ(), p.getYRot() + 180);
        String owner = p.getUUID().toString();
        for (int i = 0; i < n; i++) {
            TroopEntity t = TROOP.get().create(lv);
            if (t == null) continue;
            int x = (int) Math.floor(pos.get(i)[0]), z = (int) Math.floor(pos.get(i)[1]);
            int y = lv.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, x, z);
            t.moveTo(pos.get(i)[0], y, pos.get(i)[1], p.getYRot(), 0);
            t.setup(u, owner);
            t.realm = realm;
            made.add(t);
            ids.add(t.getUUID().toString());
        }
        Squads.Squad s = SQUADS.create(owner, null, ids);
        s.realm = realm; s.cx = p.getX(); s.cz = p.getZ();
        for (TroopEntity t : made) { t.setSquadId(s.id); lv.addFreshEntity(t); }
        src.sendSuccess(() -> Component.literal("Нанят " + s.name + ": " + made.size() + " × " + u.name() + " за " + cost), false);
        return made.size();
    }

    /** Призыв из армии wf-army: люди снимаются с армии, 1 солдат = Muster.SCALE человек; государство армии платит жалованье. */
    private static int muster(CommandSourceStack src, int armyId, int n) {
        if (!ModList.get().isLoaded("wf_army")) { src.sendFailure(Component.literal("Нужен мод wf_army")); return 0; }
        ServerPlayer p;
        try {
            p = src.getPlayerOrException();
        } catch (Exception ex) {
            src.sendFailure(Component.literal("Только для игрока"));
            return 0;
        }
        ArmyLink.Found f = ArmyLink.find(armyId);
        if (f == null) { src.sendFailure(Component.literal("Нет армии " + armyId)); return 0; }
        Muster.Plan plan = Muster.plan(f.army().units, n, DEFS.armyTypes());
        if (plan.total() == 0) { src.sendFailure(Component.literal("В армии нет столько людей: на одного солдата нужно " + Muster.SCALE + ", осадные машины не призываются")); return 0; }
        ArmyLink.take(f.army(), plan.menTaken());
        ServerLevel lv = p.serverLevel();
        String owner = p.getUUID().toString();
        List<TroopEntity> made = new ArrayList<>();
        List<String> ids = new ArrayList<>();
        List<Formations.Slot> slots = Formations.slots(Formations.Type.BLOCK, plan.total(), 1.6);
        List<double[]> pos = Formations.place(slots, p.getX(), p.getZ(), p.getYRot() + 180);
        int k = 0;
        for (var e : plan.soldiers().entrySet()) {
            TroopDefs.Unit u = DEFS.units.get(e.getKey());
            if (u == null) continue;
            for (int i = 0; i < e.getValue(); i++, k++) {
                TroopEntity t = TROOP.get().create(lv);
                if (t == null) continue;
                int x = (int) Math.floor(pos.get(k)[0]), z = (int) Math.floor(pos.get(k)[1]);
                t.moveTo(pos.get(k)[0], lv.getHeight(Heightmap.Types.MOTION_BLOCKING_NO_LEAVES, x, z), pos.get(k)[1], p.getYRot(), 0);
                t.setup(u, owner);
                t.realm = f.army().realm;
                t.armyId = armyId;
                made.add(t);
                ids.add(t.getUUID().toString());
            }
        }
        Squads.Squad s = SQUADS.create(owner, f.army().name, ids);
        s.realm = f.army().realm; s.cx = p.getX(); s.cz = p.getZ();
        for (TroopEntity t : made) { t.setSquadId(s.id); lv.addFreshEntity(t); }
        src.sendSuccess(() -> Component.literal("Призван отряд «" + s.name + "»: " + made.size() + " солдат из армии " + armyId + " (осталось людей: " + f.army().men() + ")"), false);
        return made.size();
    }

    /** Выжившие призванные солдаты игрока возвращаются в свои армии; павшие потеряны. */
    private static int returnToArmy(CommandSourceStack src) {
        ServerPlayer p;
        try {
            p = src.getPlayerOrException();
        } catch (Exception ex) {
            src.sendFailure(Component.literal("Только для игрока"));
            return 0;
        }
        if (!ModList.get().isLoaded("wf_army")) { src.sendFailure(Component.literal("Нужен мод wf_army")); return 0; }
        Map<Integer, Map<String, Integer>> byArmy = new HashMap<>();
        List<TroopEntity> gone = new ArrayList<>();
        for (TroopEntity t : LIVE.values()) if (t.isAlive() && t.armyId > 0 && t.ownerId().equals(p.getUUID().toString())) {
            byArmy.computeIfAbsent(t.armyId, k -> new HashMap<>()).merge(t.unitId(), 1, Integer::sum);
            gone.add(t);
        }
        int back = 0;
        for (var e : byArmy.entrySet()) {
            Map<String, Integer> men = Muster.back(e.getValue(), DEFS.armyTypes());
            if (ArmyLink.give(e.getKey(), men)) back += men.values().stream().mapToInt(Integer::intValue).sum();
            else gone.removeIf(t -> t.armyId == e.getKey());                                    // армии больше нет: солдаты остаются
        }
        for (TroopEntity t : gone) { onDeath(t); t.discard(); }
        int men = back;
        src.sendSuccess(() -> Component.literal("Вернулось в армии людей: " + men), false);
        return gone.size();
    }

    static Entity find(UUID id) {
        if (server == null) return null;
        for (ServerLevel lv : server.getAllLevels()) { Entity e = lv.getEntity(id); if (e != null) return e; }
        return null;
    }
}
